void s_gstat_error(const char *mess, int level);
void s_gstat_warning(const char *mess);
double r_normal(void);
double r_uniform(void);
extern int do_print_progress;
