# plotflow 0.2.1

* Fixed a bug introduced in 0.2.0 where the package only worked on Windows

# plotflow 0.2.0

* Package was updated for compatibility with ggplot2 >= 2.2.0 (now required).

* Ghostscript path is detected with `tools::find_gs_cms()` (R >= 3.1.0 now required).

* New function `x0()` was added to complement `y0()`.

* All imported functions are now declared.

* Some examples were tweaked.
